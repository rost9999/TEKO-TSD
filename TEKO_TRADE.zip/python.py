import json

with open('bar-code.txt', 'r', encoding='utf-8') as f:
    data = f.read().split('\n')
    data = [d.split('\t') for d in data]
    data = [d for d in data if len(d) == 3]

barcode = {}
article = {}

for d in data:
    barcode[d[1]] = d[0]
    article[d[0]] = d[2]



with open('data.js', 'w', encoding='utf-8') as f:
    row = 'let barcode = ' + json.dumps(barcode) + ';\n'
    row += 'let article = ' + json.dumps(article) + ';\n'
    f.write(row)


print('done')